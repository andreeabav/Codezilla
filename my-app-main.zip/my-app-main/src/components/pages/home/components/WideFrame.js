import React from 'react'
import classes from '../../../style/home.module.css';
function WideFrame() {
    return (
        <div className={classes.ctnFrame}>
        </div>
    );
}
export default WideFrame;